# Trailure — AI Travel Discovery

A beautifully designed travel experience finder powered by Claude.

## Project Structure

```
trailure/
├── api/
│   └── claude.js        ← Serverless function (proxies Anthropic API)
├── public/
│   ├── index.html       ← Landing page
│   └── explore.html     ← AI search page
├── .env.example
├── package.json
├── vercel.json
└── README.md
```

## Deploy to Vercel (5 minutes)

### Option A: Deploy via GitHub (recommended)

1. Push this folder to a GitHub repo
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo
3. In the **Environment Variables** section, add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your key from [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)
4. Click **Deploy**

Your site will be live at `https://your-project.vercel.app`

### Option B: Deploy via CLI

```bash
# Install Vercel CLI (one-time)
npm i -g vercel

# From this project folder:
vercel

# When prompted, link to a new project.
# Then set your API key:
vercel env add ANTHROPIC_API_KEY

# Paste your key when prompted, select all environments, then redeploy:
vercel --prod
```

## Local Development

```bash
# Copy the env template and add your key
cp .env.example .env.local
# Edit .env.local and paste your real Anthropic API key

# Run locally
npx vercel dev
```

Open [http://localhost:3000](http://localhost:3000)

## How It Works

The frontend (`explore.html`) sends search queries to `/api/claude`, which is a
Vercel Serverless Function. That function adds your API key server-side and
forwards the request to the Anthropic API. The key never reaches the browser.

```
Browser  →  /api/claude  →  Anthropic API
                (adds key)
```
